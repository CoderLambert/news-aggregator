"""One-session acceptance process; only loopback and explicitly pinned Ollama."""
import argparse
import ipaddress
import json
import os
import socket
import sys

allowed = frozenset(json.loads(os.environ.pop('ACCEPTANCE_OLLAMA_IPS')))
assert allowed and all(ipaddress.ip_address(ip).is_global for ip in allowed)

def audit(event, args):
    if event == 'socket.getaddrinfo':
        host = args[0]
        if host in ('ollama.com', b'ollama.com'):
            return
    elif event == 'socket.connect':
        sock, address = args
        if sock.family == socket.AF_UNIX:
            return
        host = address[0]
        if host in allowed and address[1] == 443:
            return
    else:
        return
    if host in (None, 'localhost', b'localhost'):
        return
    try:
        if ipaddress.ip_address(host).is_loopback:
            return
    except ValueError:
        pass
    raise PermissionError('ACCEPTANCE_EGRESS_DENIED')

sys.addaudithook(audit)
parser = argparse.ArgumentParser()
parser.add_argument('--config', required=True)
parser.add_argument('--port', type=int, required=True)
args = parser.parse_args()
os.environ['CONFIG_FILE_PATH'] = args.config
from litellm.proxy.proxy_server import app
import uvicorn
uvicorn.run(app, host='127.0.0.1', port=args.port, loop='asyncio', access_log=False, log_level='critical')
