"""Bounded authorized raw diagnosis. Emits only status, shapes and token counts."""
import asyncio
import json
import logging
from pathlib import Path
import socket
import sys
sys.path[:0] = [str(Path.cwd()/'backend/api/services'), str(Path.cwd()/'ops/shared-litellm-proxy')]
logging.disable(logging.CRITICAL)
from ai_endpoint_profiles import validate_endpoint_profiles
import trusted_transport as transport
key = json.loads(sys.stdin.readline())['credential']
profile = validate_endpoint_profiles([{'profile_id':'authorized_diagnostic','version':1,'provider_id':'ollama',
    'display_name':'Authorized diagnosis','protocol_family':'chat_completions_v1','api_base':'https://ollama.com/v1',
    'network_zone':'public_https','allowed_ips':sorted({row[4][0] for row in socket.getaddrinfo('ollama.com',443,type=socket.SOCK_STREAM)}),
    'auth_modes':['api_key'],'allowed_user_ids':[1],'enabled':True}])[0]
original = transport.verify_completion
def observed(raw):
    value = transport.strict_json(raw)
    row = value['choices'][0]
    msg = row['message']
    print(json.dumps({'raw_finish_reason':row.get('finish_reason'), 'content_chars':len(msg.get('content') or ''),
        'reasoning_chars':len(msg.get('reasoning_content') or ''),'tool_calls_count':len(msg.get('tool_calls') or []),
        'usage':value.get('usage')}),flush=True)
    return original(raw)
transport.verify_completion = observed
async def main():
    for kind, maximum in [('text',8),('tools',1024)]:
        payload = {'model':'minimax-m3.1-flash','stream':False,'max_tokens':maximum,
            'messages':[{'role':'user','content':'Reply with one short word confirming text output.'}]}
        if kind == 'tools':
            payload.update(messages=[{'role':'system','content':'Call byok_probe with ok=true to confirm tool support.'},
                {'role':'user','content':'Run the capability check now.'}],
                tools=[{'type':'function','function':{'name':'byok_probe','parameters':{'type':'object',
                    'properties':{'ok':{'type':'boolean'}},'required':['ok'],'additionalProperties':False}}}], tool_choice='auto')
        print(json.dumps({'kind':kind,'max_tokens':maximum}),flush=True)
        client = transport.OneShotClient(profile,provider_key=key,model_id='minimax-m3.1-flash',check_current=lambda:None)
        try:
            await client.post('https://ollama.com/v1/chat/completions',data=json.dumps(payload),stream=False)
            print(json.dumps({'validated':True}),flush=True)
        except Exception as error:
            response = getattr(error,'response',None)
            print(json.dumps({'validated':False,'error_type':type(error).__name__,
                'http_status':getattr(response,'status_code',None)}),flush=True)
        finally:
            await client.close()
asyncio.run(main())
key = None
