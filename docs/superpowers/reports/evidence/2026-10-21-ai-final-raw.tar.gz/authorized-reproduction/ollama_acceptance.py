"""Explicitly authorized model only. Credential arrives through echo-disabled stdin.

Fresh Django DB and PostgreSQL/Proxy; original loopback-only harness unchanged.
No raw exceptions, HTTP bodies, headers, prompts, completions or credentials logged.
"""
import contextlib
import io
import json
import logging
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import uuid
from unittest.mock import patch

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT / 'backend'), str(ROOT / 'crawler'), str(ROOT / 'tools/byok_t00_probe')]
from local_runtime import LocalProxy

report = {'scope': 'AUTHORIZED_OLLAMA_ONLY', 'requested_model': 'minimax-m3.1-flash:cloud',
          'api_model': None, 'checks': [], 'cleanup_complete': False}
arguments = json.loads(sys.stdin.readline())
key = arguments['credential']
research_only = arguments.get('research_only', False)
assert type(key) is str and len(key) > 24
ips = sorted({row[4][0] for row in socket.getaddrinfo('ollama.com', 443, type=socket.SOCK_STREAM)})

class AuthorizedProxy(LocalProxy):
    def _spawn(self, argv, env, log_name, **kwargs):
        if len(argv) > 1 and argv[1].endswith('/proxy_process.py'):
            argv = [argv[0], str(HERE / 'ollama_process.py'), *argv[2:]]
            env = {**env, 'ACCEPTANCE_OLLAMA_IPS': json.dumps(ips)}
            child = subprocess.Popen(argv, env=env, cwd=self.runtime, stdout=subprocess.DEVNULL,
                                     stderr=subprocess.DEVNULL, start_new_session=True, **kwargs)
            self.processes.append(child)
            return child
        return super()._spawn(argv, env, log_name, **kwargs)

def check(name, passed, **safe):
    row = {'case': name, 'status': 'PASS' if passed else 'FAIL', **safe}
    report['checks'].append(row)
    print(json.dumps(row), flush=True)
    return passed

logging.disable(logging.CRITICAL)
proxy = None
try:
    with tempfile.TemporaryDirectory(prefix='newshub-ollama-acceptance-') as directory:
        private = Path(directory)
        os.environ.update(DJANGO_ENV='development', DJANGO_DEBUG='0', RUN_MAIN='true',
            NEWS_CRAWL_ONLY='1', CRAWLER_SCHEDULER_ENABLED='0', FULL_CONTENT_WORKER_ENABLED='0',
            PUBLIC_AI_ENABLED='1', PUBLIC_SITE_MODE='full', AI_BYOK_ENABLED='1',
            DJANGO_DB_PATH=str(private / 'test.sqlite3'), CHROMA_DATA_DIR=str(private / 'chroma'),
            TTS_CACHE_DIR=str(private / 'tts'), DJANGO_SETTINGS_MODULE='newsaggregator.settings',
            DJANGO_SECRET_KEY='synthetic-ollama-acceptance-django-material-12345678901234567890',
            PROVIDER_CREDENTIAL_ENCRYPTION_KEY='synthetic-acceptance-encryption-material')
        # Django can emit server diagnostics. Capture them in memory only.
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            import django
            django.setup()
            from django.core.management import call_command
            call_command('migrate', verbosity=0)
        from django.conf import settings
        from django.contrib.auth import get_user_model
        from django.db import connections
        from django.test import override_settings
        from django.utils import timezone
        from rest_framework.test import APIClient
        from api.ai_model_models import UserAIModelConfig, AICallAttempt
        from api.models import News, Source, Category, ChatSession, ChatGPTTranslationTask, ChatGPTArticleTranslation
        from api.services import ai_private_translation as translation
        from api.tests.rss.reader_fixtures import public_legacy_article
        owner = get_user_model().objects.create_user('authorized-ollama-acceptance')
        profile = {'profile_id': 'authorized_ollama', 'version': 1, 'provider_id': 'ollama',
            'display_name': 'Authorized Ollama Cloud', 'protocol_family': 'chat_completions_v1',
            'api_base': 'https://ollama.com/v1', 'network_zone': 'public_https', 'allowed_ips': ips,
            'auth_modes': ['api_key'], 'allowed_user_ids': [owner.pk], 'enabled': True}
        manifest = private / 'manifest.json'
        manifest.write_text(json.dumps([profile]))
        proxy = AuthorizedProxy(str(ROOT / '.venv-proxy/bin/python'), 'http://127.0.0.1:1', trusted_profiles=[profile])
        with proxy, override_settings(ALLOWED_HOSTS=['testserver'], SECURE_SSL_REDIRECT=False,
            AI_BYOK_ENDPOINT_MANIFEST=str(manifest), AI_BYOK_GATEWAY_URL=proxy.url,
            AI_BYOK_GATEWAY_PROJECT_KEY=proxy.project_keys['tenant-a'], AI_BYOK_GATEWAY_PROJECT_KEY_FILE=''):
            api = APIClient()
            api.force_authenticate(owner)
            base = '/api/me/ai/connections/'
            created = api.post(base, {'provider_id': 'ollama', 'endpoint_profile': profile['profile_id'],
                'display_name': 'Ollama authorized acceptance', 'auth_mode': 'api_key', 'api_key': key,
                'request_id': str(uuid.uuid4())}, format='json')
            assert check('save_connection_no_inference', created.status_code == 201)
            models_url = base + created.data['id'] + '/models/'
            catalog = api.post(models_url + 'discover/', {}, format='json')
            assert check('authorized_catalog', catalog.status_code == 200, http_status=catalog.status_code)
            ids = catalog.data['models']
            # Official Ollama docs distinguish CLI :cloud from direct API name.
            model_name = 'minimax-m3.1-flash:cloud' if 'minimax-m3.1-flash:cloud' in ids else 'minimax-m3.1-flash'
            assert model_name in ids
            report['api_model'] = model_name
            check('official_cli_api_identity_mapping', True, api_model=model_name)
            created = api.post(models_url, {'model_id': model_name}, format='json')
            assert check('save_manual_model', created.status_code == 201)
            model_id = created.data['id']
            for kind in ('text', 'tools'):
                result = api.post(models_url + model_id + '/probe/', {'probe_kind': kind, 'revision': 1,
                    'request_id': str(uuid.uuid4())}, format='json')
                check(kind + '_probe', result.status_code == 200 and result.data['status'] == 'succeeded',
                      http_status=result.status_code, probe_status=result.data.get('status'),
                      safe_error_code=result.data.get('safe_error_code'))
            model = UserAIModelConfig.objects.get(pk=model_id)
            report['capabilities'] = {k: {'status': v.get('status')} for k,v in model.capability_results.items() if isinstance(v,dict)}
            if all(model.capability_results.get(k,{}).get('status') == 'supported' for k in ('text','tools')):
                from api.services.research.byok_execution import capture_snapshot, call_model_once, preserve_native_fields
                payload = capture_snapshot(owner, model_id)
                messages = [{'role': 'system', 'content': 'Call byok_probe with ok=true once. After its result, answer confirmed.'},
                    {'role': 'user', 'content': 'Run the capability check.'}]
                tools = [{'type': 'function', 'function': {'name': 'byok_probe', 'parameters': {'type': 'object',
                    'properties': {'ok': {'type': 'boolean'}}, 'required': ['ok'], 'additionalProperties': False}}}]
                try:
                    stage = 'first_tool_request'
                    result = call_model_once(payload, owner_id=owner.pk, messages=messages, tools=tools, execution_guard=lambda:None)
                    msg = result.choices[0].message
                    calls = msg.tool_calls or []
                    assert len(calls) == 1 and calls[0].function.name == 'byok_probe'
                    from api.services.research.agent_loop import _serialize_assistant_message
                    history = _serialize_assistant_message(msg, native=True)
                    messages += [history, {'role': 'tool', 'tool_call_id': calls[0].id, 'content': '{"ok":true}'}]
                    stage = 'tool_result_replay'
                    result = call_model_once(payload, owner_id=owner.pk, messages=messages, tools=tools, execution_guard=lambda:None)
                    check('research_function_replay_same_model', result.choices[0].finish_reason == 'stop'
                        and bool(result.choices[0].message.content) and not result.choices[0].message.tool_calls)
                except Exception as error:
                    check('research_function_replay_same_model', False, safe_failure_type=type(error).__name__,
                        stage=stage, safe_error_code=getattr(error,'code',None))
            text_ok = model.capability_results.get('text',{}).get('status') == 'supported'
            if text_ok and not research_only:
                source = Source.objects.create(name='Acceptance publisher', url='https://example.org/', language='en')
                category = Category.objects.create(name='Acceptance', slug='acceptance')
                article = public_legacy_article(News.objects.create(title='A simple acceptance article',
                    url='https://example.org/acceptance', source=source, category=category,
                    content='A synthetic summary.', publish_time=timezone.now(), full_content_state='legacy',
                    full_content='The project planted three trees in a local park on Monday.'))
                result = api.post(f'/api/news/{article.pk}/chat/', {'question': 'How many trees were planted? Answer in one short sentence.',
                    'model_config_id': model_id, 'billing_consent': True, 'turn_id': str(uuid.uuid4())}, format='json')
                wire = b''.join(result.streaming_content) if result.status_code == 200 else b''
                persisted = ChatSession.objects.filter(user=owner, news=article).first()
                check('article_qa_raw_stream_and_persistence', b'"status": "complete"' in wire and persisted is not None
                    and any(m['role']=='assistant' and m.get('content') for m in persisted.messages), http_status=result.status_code)
                with patch.object(translation, '_dispatch'):
                    result = api.post(f'/api/news/{article.pk}/byok-translation/', {'model_config_id': model_id,
                        'billing_consent': True, 'target_language': 'zh'}, format='json', HTTP_IDEMPOTENCY_KEY=str(uuid.uuid4()))
                if result.status_code == 202:
                    task = ChatGPTTranslationTask.objects.get(pk=result.data['task_id'])
                    translation.run_translation(task.pk, task.generation)
                    task.refresh_from_db()
                    check('article_translation_raw_stream_and_persistence', task.status == 'succeeded'
                        and ChatGPTArticleTranslation.objects.filter(user=owner, news=article).exists(), task_status=task.status,
                        safe_error_code=task.error_code)
                else:
                    check('article_translation_raw_stream_and_persistence', False, http_status=result.status_code)
            else:
                report['checks'].append({'case': 'article_qa_and_translation', 'status': 'BLOCKED', 'reason': 'text_probe_unverified'})
            report['attempt_statuses'] = list(AICallAttempt.objects.filter(user=owner).values_list('status', flat=True))
        connections.close_all()
except BaseException as error:
    report['safe_failure_type'] = type(error).__name__
finally:
    key = None
    report['cleanup_complete'] = bool(proxy and proxy.cleanup_complete)
    report['candidate'] = subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip()
    path = ROOT / 'docs/superpowers/reports/evidence/2026-10-21-ai-ollama-live.json'
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False)+'\n')
    print(json.dumps({'report_written': True, 'cleanup_complete': report['cleanup_complete'],
        'safe_failure_type': report.get('safe_failure_type')}), flush=True)
