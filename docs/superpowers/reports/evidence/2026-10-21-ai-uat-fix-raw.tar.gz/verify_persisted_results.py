"""Verify the existing paid requests with read-only receipts, never replay."""
import json
from pathlib import Path
import sqlite3
import httpx

here=Path(__file__).parent
state=json.loads((here/'state.json').read_text())
path=Path('/tmp/newshub-ai-uatfix-live-results.json')
rows=json.loads(path.read_text())
with httpx.Client(base_url=state['url'],trust_env=False,timeout=10) as client:
    csrf=client.get('/api/auth/csrf/').json()['csrfToken']
    login=client.post('/api/auth/login/',json={'username':state['username'],'password':state['password']},
        headers={'X-CSRFToken':csrf,'Origin':state['url']})
    assert login.status_code==200
    response=client.get('/api/news/1/chat/')
    assert response.status_code==200
    assistants=[m for m in response.json()['messages'] if m.get('role')=='assistant']
    assert len(assistants)==1
    answer=assistants[0]
    assert answer.get('status')=='complete' and answer.get('content','').strip()
    assert answer.get('model_source',{}).get('provider')=='ollama'
    assert answer.get('model_source',{}).get('model')=='minimax-m3.1-flash'
db=sqlite3.connect('file:/tmp/newshub-ai-preview-data-aahw4klr/preview.sqlite3?mode=ro',uri=True)
turns=db.execute('SELECT status FROM api_articlechatturn WHERE user_id=1 AND news_id=1').fetchall()
runs=db.execute('SELECT status,error_code FROM api_researchrun WHERE user_id=1').fetchall()
assert turns==[('complete',)] and runs==[('succeeded','')]
# Preserve the first script's parser failure transparently. Chat uses __META__
# frames, unlike the research endpoint's data: JSON event wire format.
initial=Path('/tmp/newshub-ai-uatfix-live-initial.json')
assert not initial.exists()
initial.write_text(path.read_text())
for row in rows:
    if row['case']=='configured_model_article_qa':
        row.update(status='PASS',proof='owner_scoped_http_history_and_terminal_db_receipt',
            initial_harness_result='FAIL_wrong_research_wire_parser',
            stream_terminal_captured=False,provider_replayed=False)
rows.append({'case':'configured_model_research_durable_result','status':'PASS',
             'proof':'owner_scoped_terminal_db_receipt','provider_replayed':False})
path.write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'article_qa_persisted':'PASS','research_persisted':'PASS',
    'extra_model_calls':0,'initial_harness_parser_failure_preserved':True}))
