"""Authorized UAT against the existing owner's configured model. No Key read/echo."""
import json
from pathlib import Path
import uuid
import httpx

state=json.loads(Path(__file__).with_name('state.json').read_text())
rows=[]
def record(name,condition,**safe):
    value={'case':name,'status':'PASS' if condition else 'FAIL',**safe}
    rows.append(value);print(json.dumps(value),flush=True)
    return condition

with httpx.Client(base_url=state['url'],trust_env=False,timeout=httpx.Timeout(90,connect=5)) as client:
    csrf=client.get('/api/auth/csrf/').json()['csrfToken']
    result=client.post('/api/auth/login/',json={'username':state['username'],'password':state['password']},
        headers={'X-CSRFToken':csrf,'Origin':state['url']})
    assert result.status_code==200
    csrf=client.cookies.get('csrftoken')
    client.headers.update({'X-CSRFToken':csrf,'Origin':state['url']})
    listing=client.get('/api/me/ai/connections/').json()
    connections=listing['connections']
    choices=[]
    for connection in connections:
        if connection['endpoint_profile']!='preview_ollama_cloud' or not connection['is_enabled']:continue
        models=client.get('/api/me/ai/connections/'+connection['id']+'/models/').json()['models']
        for model in models:
            if model['model_id']=='minimax-m3.1-flash':choices.append((connection,model))
    assert len(choices)==1,'CONFIGURED_MODEL_AMBIGUOUS'
    connection,model=choices[0]
    model_id=model['id']
    record('current_model_has_text_proof',model['capabilities']['text']=='supported')
    if model['capabilities']['tools']!='supported':
        refused=client.post('/api/research/',json={'query':'Synthetic admission check','local_only':True,
            'model_config_id':model_id,'consent':True},headers={'Idempotency-Key':str(uuid.uuid4())})
        result=refused.json()
        assert record('missing_tools_rejected_before_task',refused.status_code==409
            and result.get('request_state')=='rejected',safe_error_code=result.get('error_code'))
        probe=client.post('/api/me/ai/connections/'+connection['id']+'/models/'+model_id+'/probe/',
            json={'probe_kind':'tools','revision':model['config_revision'],'request_id':str(uuid.uuid4())})
        result=probe.json()
        assert record('configured_model_live_tools_probe',probe.status_code==200 and result.get('status')=='succeeded',
            safe_error_code=result.get('safe_error_code'))
    prefs=client.get('/api/me/ai/task-preferences/').json()
    default=next(p for p in prefs['preferences'] if p['task_kind']=='default')
    assert record('default_model_research_eligibility_refreshed',default['model']['research_eligible'] is True)
    with client.stream('POST','/api/news/1/chat/',json={'question':'How many trees were planted? Answer in one short sentence.',
        'model_config_id':model_id,'billing_consent':True,'turn_id':str(uuid.uuid4())}) as response:
        if response.status_code==200:
            complete=False
            for line in response.iter_lines():
                if line.startswith('data:'):
                    event=json.loads(line[5:].strip())
                    if event.get('status')=='complete':complete=True
            record('configured_model_article_qa',complete,http_status=response.status_code)
        else:
            response.read();value=response.json()
            record('configured_model_article_qa',False,http_status=response.status_code,safe_error_code=value.get('error_code'))
    with client.stream('POST','/api/research/',json={'query':'你好！这是一项连通验收，请只简短回复你好，不要调用任何工具。',
        'local_only':True,'model_config_id':model_id,'consent':True},headers={'Idempotency-Key':str(uuid.uuid4())}) as response:
        if response.status_code==200:
            complete=False;terminal_error=None;tool_seen=False
            session=response.headers.get('session-id');run=response.headers.get('run-id')
            for line in response.iter_lines():
                if not line.startswith('data:'):continue
                event=json.loads(line[5:].strip())
                if event.get('type')=='complete':complete=True
                if event.get('type')=='error':terminal_error=event.get('error_code','error')
                if event.get('type')=='tool_call':
                    tool_seen=True
                    if session and run:client.post('/api/research/'+session+'/cancel/',json={'run_id':run})
                    break
            record('configured_model_research_create_complete',complete and not tool_seen,
                http_status=response.status_code,safe_error_code=terminal_error,unexpected_tools=tool_seen)
        else:
            response.read();value=response.json()
            record('configured_model_research_create_complete',False,http_status=response.status_code,safe_error_code=value.get('error_code'))
Path('/tmp/newshub-ai-uatfix-live-results.json').write_text(json.dumps(rows,indent=2)+'\n')
